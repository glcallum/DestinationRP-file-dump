Crafting = {}
-- You can configure locations here
Crafting.Locations = {
    [1] = {x = 1015.003, y = -3158.878, z = -38.907},
}
--[[
    You can add or remove if you want, be sure to use the right format like this:
    ["item_name"] = {
        label = "Item Label",
        needs = {
            ["item_to_use_name"] = {label = "Item Use Label", count = 1}, 
            ["item_to_use_name2"] = {label = "Item Use Label", count = 2},
        },
        threshold = 0,
    },

    #! 
        Threshold level is a level that gets saved (in the database) by crafting, if you craft succefully you gain points, if you fail you lose points.
        The threshold level can be changed to your liking.
    #!

    Also if you don't have the items below make sure to remove it and create your own version.
]]--
Crafting.Items = {
    ["WEAPON_SNSPISTOL"] = {
        label = "SNS Pistol",
        needs = {
            ["copper"] = {label = "Copper", count = 1},
            ["crack"] = {label = "Crack Cocaine", count = 2},
        },
        threshold = 0,
    },
    ["lockpick"] = {
        label = "Lockpick",
        needs = {
            ["iron"] = {label = "Iron Bars", count = 3},
        },
        threshold = 0,
    },
    ["WEAPON_COMBATPISTOL"] = {
        label = "Combat Pistol",
        needs = {
            ["iron"] = {label = "Iron", count = 50},
            ["copper"] = {label = "Copper", count = 20},
            ["plastic"] = {label = "Plastic", count = 5},
        },
        threshold = 0,
    },
    ["WEAPON_HEAVYPISTOL"] = {
        label = "Heavy Pistol",
        needs = {
            ["livitherium"] = {label = "Livitherium", count = 1},
            ["plastic"] = {label = "Plastic", count = 10},
            ["iron"] = {label = "Iron", count = 50},
            ["copper"] = {label = "Copper", count = 25},
        },
        threshold = 0,
    },
    ["WEAPON_REVOLVER"] = {
        label = "Revolver",
        needs = {
            ["iron"] = {label = "Iron", count = 75},
            ["plastic"] = {label = "Plastic", count = 5},
            ["copper"] = {label = "Copper", count = 25},
        },
        threshold = 0,
    },
    ["WEAPON_APPISTOL"] = {
        label = "AP Pistol",
        needs = {
            ["livitherium"] = {label = "Livitherium", count = 2},
            ["plastic"] = {label = "Plastic", count = 10},
            ["copper"] = {label = "Copper", count = 25},
            ["iron"] = {label = "Iron", count = 50},
        },
        threshold = 0,
    },
    ["WEAPON_SAWNOFFSHOTGUN"] = {
        label = "Sawed Off Shotgun",
        needs = {
            ["copper"] = {label = "Copper", count = 10},
            ["iron"] = {label = "Iron", count = 20},
        },
        threshold = 0,
    },
    ["WEAPON_DBSHOTGUN"] = {
        label = "Double Barrel Shotgun",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 10},
            ["iron"] = {label = "Iron", count = 15},
        },
        threshold = 0,
    },
    ["WEAPON_MICROSMG"] = {
        label = "Micro SMG",
        needs = {
            ["copper"] = {label = "Copper", count = 35},
            ["iron"] = {label = "Iron", count = 60},
			["plastic"] = {label = "Plastic", count = 5},
        },
        threshold = 0,
    },
    ["WEAPON_MINISMG"] = {
        label = "Mini SMG",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 25},
            ["iron"] = {label = "Iron", count = 30},
        },
        threshold = 0,
    },
    ["WEAPON_GUSENBERG"] = {
        label = "Gusenberg Sweeper",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 45},
            ["iron"] = {label = "Iron", count = 60},
			["livitherium"] = {label = "Livitherium", count = 3},
        },
        threshold = 0,
    },
    ["WEAPON_MACHINEPISTOL"] = {
        label = "Machine Pistol",
        needs = {
            ["copper"] = {label = "Copper", count = 20},
            ["iron"] = {label = "Iron", count = 20},
        },
        threshold = 0,
    },
    ["WEAPON_ASSAULTRIFLE"] = {
        label = "Assault Rifle",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 10},
            ["iron"] = {label = "Iron", count = 100},
			["copper"] = {label = "Copper", count = 50},
			["livitherium"] = {label = "Livitherium", count = 5},
			["plastic"] = {label = "Plastic", count = 10},
        },
        threshold = 0,
    },
    ["WEAPON_COMPACTRIFLE"] = {
        label = "Compact Rifle",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 65},
            ["iron"] = {label = "Iron", count = 75},
        },
        threshold = 0,
    },
    ["WEAPON_SMG"] = {
        label = "SMG",
        needs = {
            ["plastic"] = {label = "Plastic", count = 15},
            ["iron"] = {label = "Iron", count = 65},
			["copper"] = {label = "Copper", count = 100}
        },
        threshold = 0,
    },
    ["WEAPON_PISTOL50"] = {
        label = "Pistol .50",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 10},
            ["iron"] = {label = "Iron", count = 50},
			["plastic"] = {label = "Plastic", count = 10}
        },
        threshold = 0,
    },
    ["WEAPON_ASSAULTSHOTGUN"] = {
        label = "Assault Shotgun",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 10},
            ["iron"] = {label = "Iron", count = 75},
			["copper"] = {label = "Copper", count = 50},
			["livitherium"] = {label = "Livitherium", count = 3},
			["plastic"] = {label = "Plastic", count = 10},
        },
        threshold = 0,
    },
    ["WEAPON_VINTAGEPISTOL"] = {
        label = "Vintage Pistol",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 10},
            ["iron"] = {label = "Iron", count = 15},
			["gold"] = {label = "Gold", count = 15},
        },
        threshold = 0,
    },
    ["arAmmo"] = {
        label = "Assault Rifle Ammo",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 4},
            ["plastic"] = {label = "Plastic", count = 2},
            ["iron"] = {label = "Iron", count = 20},
			["gold"] = {label = "Gold", count = 20},
        },
        threshold = 0,
    },
    ["mgAmmo"] = {
        label = "MG Ammo Box",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 2},
            ["plastic"] = {label = "Plastic", count = 1},
            ["iron"] = {label = "Iron", count = 10},
			["gold"] = {label = "Gold", count = 20},
        },
        threshold = 0,
    },
    ["oxycutter"] = {
        label = "Plasma Torch",
        needs = {
            ["pine_processed"] = {label = "Processed Pine", count = 15},
            ["plastic"] = {label = "Plastic", count = 10},
            ["iron"] = {label = "Iron", count = 35},
			["gold"] = {label = "Gold", count = 21},
        },
        threshold = 0,
    },
}