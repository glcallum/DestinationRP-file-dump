Config = {}

Config.DrawDistance = 30
Config.Draw3DDistance = 5