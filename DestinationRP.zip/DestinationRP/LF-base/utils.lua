function getOrElse(value, default)
    if value ~= nil then
        return value
    else
        return default
    end
end
