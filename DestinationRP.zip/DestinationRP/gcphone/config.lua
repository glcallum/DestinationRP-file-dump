FixePhone = {
  -- Poste de police
  ['911'] = { name =  "Central Police", coords = { x = 441.2, y = -979.7, z = 30.58 } },
  
  -- Cabine proche du poste de police
  ['008-0001'] = { name = "Pay Phone", coords = { x = 372.25, y = -965.75, z = 28.58 } },

  -- EMS
  ['611'] = { name = "EMS Telephone", coords = { x = 262.04, y = -1359.82, z = 24.54 } },
}

ShowNumberNotification = true -- Show Number or Contact Name when you receive new SMS