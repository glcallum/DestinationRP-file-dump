local Drag = {
	Distance = 3,
	Dragging = false,
	Dragger = -1,
	Dragged = false,
}

function Drag:GetPlayers()
	local Players = {}
    
	for Index = 0, 255 do
		if NetworkIsPlayerActive(Index) then
			table.insert(Players, Index)
		end
	end

    return Players
end

function Drag:GetClosestPlayer()
    local Players = self:GetPlayers()
    local ClosestDistance = -1
    local ClosestPlayer = -1
    local PlayerPed = PlayerPedId()
    local PlayerPosition = GetEntityCoords(PlayerPed, false)
    
    for Index = 1, #Players do
    	local TargetPed = GetPlayerPed(Players[Index])
    	if PlayerPed ~= TargetPed then
    		local TargetCoords = GetEntityCoords(TargetPed, false)
    		local Distance = #(PlayerPosition - TargetCoords)

    		if ClosestDistance == -1 or ClosestDistance > Distance then
    			ClosestPlayer = Players[Index]
    			ClosestDistance = Distance
    		end
    	end
    end
    
    return ClosestPlayer, ClosestDistance
end

RegisterNetEvent("Carry")
AddEventHandler("Carry", function(Dragger)
	Drag.Dragging = not Drag.Dragging
	Drag.Dragger = Dragger
end)

RegisterCommand("carry", function(source, args, fullCommand)
	local Player, Distance = Drag:GetClosestPlayer()

	if Distance ~= -1 and Distance < Drag.Distance then
		TriggerServerEvent("Carry", GetPlayerServerId(Player))
		RequestAnimDict('missfinale_c2mcs_1')
		while not HasAnimDictLoaded('missfinale_c2mcs_1') do
			Citizen.Wait(100)
		end   
		TaskPlayAnim(GetPlayerPed(-1), "missfinale_c2mcs_1", "fin_c2_mcs_1_camman", 1.0, 1.0, -1, 49, 0, 0, 0, 0)
		
	else
		TriggerEvent("chat:addMessage", {
			color = {255, 0, 0},
			multiline = true,
			args = {"Carry", "Please get closer to the target!"},
		})
	end
end, false)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)

		if NetworkIsSessionStarted() then
			TriggerEvent("chat:addSuggestion", "/carry", "Toggle carry the closest player!")
			return
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if Drag.Dragging then
			local PlayerPed = PlayerPedId()

			Drag.Dragged = true
	AttachEntityToEntity(GetPlayerPed(-1), GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)), 1, -0.68, -0.2, 1.1, 150.0, 175.0, 1.0, 1, 1, 0, 1, 0, 1)
	SetBlockingOfNonTemporaryEvents(playerPed, true)		
	SetPedSeeingRange(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)), 0.0)		
	SetPedHearingRange(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)), 0.0)		
	SetPedFleeAttributes(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)), 0, false)		
	SetPedKeepTask(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)), true)	
	Citizen.Wait(1000)

	RequestAnimDict('dead')
	while not HasAnimDictLoaded('dead') do
		Citizen.Wait(100)
	end 
	    TaskPlayAnim(GetPlayerPed(-1), "dead", "dead_f", 8.0, 8.0, -1, 1, 0, 0, 0, 0)

	RequestAnimDict('amb@world_human_bum_slumped@male@laying_on_left_side@base')
	while not HasAnimDictLoaded('amb@world_human_bum_slumped@male@laying_on_left_side@base') do
		Citizen.Wait(100)
	end  
	TaskPlayAnim(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)), "amb@world_human_bum_slumped@male@laying_on_left_side@base", "base", 8.0, 8.0, -1, 1, 999.0, 0, 0, 0)
	local holdingBody = true

		Citizen.Wait(1)

		
		if IsControlJustPressed(0, 38) or (GetHashKey("WEAPON_UNARMED") ~= GetSelectedPedWeapon(GetPlayerPed(-1)))  then
			holdingBody = false
			DetachEntity(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)))
		end
		else
			if Drag.Dragged then
				local PlayerPed = PlayerPedId()

				if not IsPedInParachuteFreeFall(PlayerPed) then
					Drag.Dragged = false
					DetachEntity(PlayerPed, true, false)
					ClearPedTasks(PlayerPed)
					ClearPedTasks(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)))
					Citizen.Wait(2000)
					RequestAnimDict('anim@narcotics@trash')
  while not HasAnimDictLoaded('anim@narcotics@trash') do
	  Citizen.Wait(100)
  end
	TaskPlayAnim(GetPlayerPed(GetPlayerFromServerId(Drag.Dragger)),'anim@narcotics@trash', 'drop_front',0.9, -8, 1500, 49, 3.0, 0, 0, 0)    
				end
			end
		end
	end
end)