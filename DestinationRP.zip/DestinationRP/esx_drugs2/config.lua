Config              = {}
Config.MarkerType   = 27
Config.DrawDistance = 100.0
Config.ZoneSize     = {x = 3.0, y = 3.0, z = 1.0}
Config.MarkerColor  = {r = 255, g = 0, b = 0}

Config.RequiredCopsCoke  = 3
Config.RequiredCopsMeth  = 2
Config.RequiredCopsWeed  = 1
Config.RequiredCopsOpium = 3

Config.TimeToFarm    = 12 * 1000
Config.TimeToProcess = 25 * 1000
Config.TimeToSell    = 5  * 1000

Config.Locale = 'en'

Config.Zones = {
	CokeField =			{x = -1869.71,	y = 2109.63,	z = 135.63,	name = _U('coke_field'),		sprite = 501,	color = 40},
	CokeProcessing =	{x = 1535.55,	y = 1703.19,	z = 109.7},
	CokeDealer =		{x = -434.26,	y = 1091.6,		z = 332.54,	name = _U('coke_dealer'),		sprite = 500,	color = 75},
	MethField =			{x = 2561.81,	y = 4424.58,	z = 38.72,	name = _U('meth_field'),		sprite = 499,	color = 26},
	MethProcessing =	{x = 1392.42,	y = 3605.92,	z = 38.94},
	MethDealer =		{x = -45.50,	y = -1289.89,	z = 29.22,	name = _U('meth_dealer'),		sprite = 500,	color = 75},
	WeedField =			{x = 2152.08,	y = 5116.95,	z = 47.07,	name = _U('weed_field'),		sprite = 496,	color = 52},
	WeedProcessing =	{x = 1551.98,		y = 2189.49,	z = 78.84},
	WeedDealer =		{x = 341.42,	y = -1270.64,	z = 32.09,	name = _U('weed_dealer'),		sprite = 500,	color = 75},
	OpiumField =		{x = 501.13,	y = 6467.49,	z = 30.86,	name = _U('opium_field'),		sprite = 51,	color = 60},
	OpiumProcessing =	{x = -50.24,	y = 1911.16,	z = 195.71},
	OpiumDealer =		{x = 1011.12,	y = -2895.61,	z = 39.16,	name = _U('opium_dealer'),		sprite = 500,	color = 75}
}
