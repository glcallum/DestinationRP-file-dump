Locales['br'] = {
	['used_bread'] = 'você comeu ~y~1x~s~ ~b~pão~s~',
	['used_water'] = 'você tomou ~y~1x~s~ ~b~água~s~',
}