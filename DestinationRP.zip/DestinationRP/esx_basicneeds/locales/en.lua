Locales['en'] = {
    ['used_bread'] = 'you have used ~y~1x~s~ ~b~bread~s~',
	['used_water'] = 'you have used ~y~1x~s~ ~b~water~s~',
	['used_chips'] = 'you have used ~y~1x~s~ ~b~chips~s~',
	['used_cocacola'] = 'you have used ~y~1x~s~ ~b~cocacola~s~',
	['used_chocolate'] = 'you have used ~y~1x~s~ ~b~chocolate~s~',
	['used_energy'] = 'you have used ~y~1x~s~ ~b~energy drink~s~',
	['used_hamburger'] = 'you have used ~y~1x~s~ ~b~hamburger~s~'

}

	