ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

-- C O N F I G --
interactionDistance = 3.5 --The radius you have to be in to interact with the vehicle.
lockDistance = 25 --The radius you have to be in to lock your vehicle.

--  V A R I A B L E S --
engineoff = false
saved = false
controlsave_bool = false

-- E N G I N E --
IsEngineOn = true
RegisterNetEvent('engine')
AddEventHandler('engine',function() 
	local player = GetPlayerPed(-1)
	
	if (IsPedSittingInAnyVehicle(player)) then 
		local vehicle = GetVehiclePedIsIn(player,false)
		
		if IsEngineOn == true then
			IsEngineOn = false
			SetVehicleEngineOn(vehicle,false,false,false)
		else
			IsEngineOn = true
			SetVehicleUndriveable(vehicle,false)
			SetVehicleEngineOn(vehicle,true,false,false)
		end
		
		while (IsEngineOn == false) do
			SetVehicleUndriveable(vehicle,true)
			Citizen.Wait(0)
		end
	end
end)

RegisterNetEvent('engineoff')
AddEventHandler('engineoff',function() 
		local player = GetPlayerPed(-1)

        if (IsPedSittingInAnyVehicle(player)) then 
            local vehicle = GetVehiclePedIsIn(player,false)
			engineoff = true
			exports['mythic_notify']:DoHudText('inform', "Engine ~r~off~s~.")
			while (engineoff) do
			SetVehicleEngineOn(vehicle,false,false,false)
			SetVehicleUndriveable(vehicle,true)
			Citizen.Wait(0)
			end
		end
end)
RegisterNetEvent('engineon')
AddEventHandler('engineon',function() 
    local player = GetPlayerPed(-1)

        if (IsPedSittingInAnyVehicle(player)) then 
            local vehicle = GetVehiclePedIsIn(player,false)
			engineoff = false
			SetVehicleUndriveable(vehicle,false)
			SetVehicleEngineOn(vehicle,true,false,false)
			exports['mythic_notify']:DoHudText('inform', "Engine ~g~on~s~.")
	end
end)
-- T R U N K --
RegisterNetEvent('trunk')
AddEventHandler('trunk',function() 
	local player = GetPlayerPed(-1)
			if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			
			local isopen = GetVehicleDoorAngleRatio(vehicle,5)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if distanceToVeh <= interactionDistance then
				if (isopen == 0) then
				SetVehicleDoorOpen(vehicle,5,0,0)
				else
				SetVehicleDoorShut(vehicle,5,0)
				end
			else
				exports['mythic_notify']:DoHudText('inform', "~r~You must be near your vehicle to do that.")
			end
end)
-- R E A R  D O O R S --
RegisterNetEvent('rdoors')
AddEventHandler('rdoors',function() 
	local player = GetPlayerPed(-1)
    		if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			local isopen = GetVehicleDoorAngleRatio(vehicle,2) and GetVehicleDoorAngleRatio(vehicle,3)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if distanceToVeh <= interactionDistance then
				if (isopen == 0) then
				SetVehicleDoorOpen(vehicle,2,0,0)
				SetVehicleDoorOpen(vehicle,3,0,0)
				else
				SetVehicleDoorShut(vehicle,2,0)
				SetVehicleDoorShut(vehicle,3,0)
				end
			else
				exports['mythic_notify']:DoHudText('inform', "~r~You must be near your vehicle to do that.")
			end
end)

RegisterNetEvent('fdoors')
AddEventHandler('fdoors',function() 
	local player = GetPlayerPed(-1)
    		if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			local isopen = GetVehicleDoorAngleRatio(vehicle,0) and GetVehicleDoorAngleRatio(vehicle,1)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if distanceToVeh <= interactionDistance then
				if (isopen == 0) then
				SetVehicleDoorOpen(vehicle,0,0,0)
				SetVehicleDoorOpen(vehicle,1,0,0)
				else
				SetVehicleDoorShut(vehicle,0,0)
				SetVehicleDoorShut(vehicle,1,0)
				end
			else
				exports['mythic_notify']:DoHudText('inform', "~r~You must be near your vehicle to do that.")
			end
end)


RegisterNetEvent('sswap1')
AddEventHandler('sswap1',function() 
	local player = GetPlayerPed(-1)
    		if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			local isPedInSeat = IsVehicleSeatFree(vehicle, 0)
			print(isPedInSeat)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if IsPedInAnyVehicle(player, false) then
				if IsPedInAnyPoliceVehicle(player) then
					exports['mythic_notify']:DoHudText('error', "Not allowed in police vehicle")
					
				else
					if (isPedInSeat == 1) then
						SetPedIntoVehicle(player, vehicle, 0)
					else
						exports['mythic_notify']:DoHudText('error', "Seat is Occupied")
					end
				end
			else
				exports['mythic_notify']:DoHudText('error', "Not in vehicle")
			end
end)

RegisterNetEvent('sswap2')
AddEventHandler('sswap2',function() 
	local player = GetPlayerPed(-1)
    		if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			local isPedInSeat = IsVehicleSeatFree(vehicle, 1)
			print(isPedInSeat)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if IsPedInAnyVehicle(player, false) then
				if IsPedInAnyPoliceVehicle(player) then
					exports['mythic_notify']:DoHudText('error', "Not allowed in police vehicle")
					
				else
					if (isPedInSeat == 1) then
						SetPedIntoVehicle(player, vehicle, 1)
					else
						exports['mythic_notify']:DoHudText('error', "Seat is Occupied")
					end
				end
			else
				exports['mythic_notify']:DoHudText('error', "Not in vehicle")
			end
end)

RegisterNetEvent('sswap3')
AddEventHandler('sswap3',function() 
	local player = GetPlayerPed(-1)
    		if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			local isPedInSeat = IsVehicleSeatFree(vehicle, 2)
			print(isPedInSeat)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if IsPedInAnyVehicle(player, false) then
				if IsPedInAnyPoliceVehicle(player) then
					exports['mythic_notify']:DoHudText('error', "Not allowed in police vehicle")
					
				else
					if (isPedInSeat == 1) then
						SetPedIntoVehicle(player, vehicle, 2)
					else
						exports['mythic_notify']:DoHudText('error', "Seat is Occupied")
					end
				end
			else
				exports['mythic_notify']:DoHudText('error', "Not in vehicle")
			end
end)

RegisterNetEvent('sswap4')
AddEventHandler('sswap4',function() 
	local player = GetPlayerPed(-1)
    		if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			local isPedInSeat = IsVehicleSeatFree(vehicle, -1)
			print(isPedInSeat)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if IsPedInAnyVehicle(player, false) then
				if IsPedInAnyPoliceVehicle(player) then
					exports['mythic_notify']:DoHudText('error', "Not allowed in police vehicle")
					
				else
					if (isPedInSeat == 1) then
						SetPedIntoVehicle(player, vehicle, -1)
					else
						exports['mythic_notify']:DoHudText('error', "Seat is Occupied")
					end
				end
			else
				exports['mythic_notify']:DoHudText('error', "Not in vehicle")
			end
end)

RegisterNetEvent('sswap5')
AddEventHandler('sswap5',function() 
	local player = GetPlayerPed(-1)
    		if controlsave_bool == true then
				vehicle = saveVehicle
			else
				vehicle = GetVehiclePedIsIn(player,false)
			end
			local isPedInSeat = IsVehicleSeatFree(vehicle, -2)
			print(isPedInSeat)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if IsPedInAnyVehicle(player, false) then
				if IsPedInAnyPoliceVehicle(player) then
					exports['mythic_notify']:DoHudText('error', "Not allowed in police vehicle")
					
				else
					if (isPedInSeat == 1) then
						SetPedIntoVehicle(player, vehicle, -2)
					else
						exports['mythic_notify']:DoHudText('error', "Seat is Occupied")
					end
				end
			else
				exports['mythic_notify']:DoHudText('error', "Not in vehicle")
			end
end)

-- H O O D --
RegisterNetEvent('hood')
AddEventHandler('hood',function() 
	local player = GetPlayerPed(-1)
    	if controlsave_bool == true then
			vehicle = saveVehicle
		else
			vehicle = GetVehiclePedIsIn(player,false)
		end
			
			local isopen = GetVehicleDoorAngleRatio(vehicle,4)
			local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
			
			if distanceToVeh <= interactionDistance then
				if (isopen == 0) then
				SetVehicleDoorOpen(vehicle,4,0,0)
				else
				SetVehicleDoorShut(vehicle,4,0)
				end
			else
				exports['mythic_notify']:DoHudText('inform', "~r~You must be near your vehicle to do that.")
			end
end)
-- L O C K --
RegisterNetEvent('lockLights')
AddEventHandler('lockLights',function()
local vehicle = saveVehicle
	StartVehicleHorn(vehicle, 100, 1, false)
	SetVehicleLights(vehicle, 2)
	Wait (200)
	SetVehicleLights(vehicle, 0)
	StartVehicleHorn(vehicle, 100, 1, false)
	Wait (200)
	SetVehicleLights(vehicle, 2)
	Wait (400)
	SetVehicleLights(vehicle, 0)
end)

RegisterNetEvent('lock')
AddEventHandler('lock',function()
	local player = GetPlayerPed(-1)
    local vehicle = saveVehicle
	local islocked = GetVehicleDoorLockStatus(vehicle)
	local distanceToVeh = GetDistanceBetweenCoords(GetEntityCoords(player), GetEntityCoords(vehicle), 1)
		if DoesEntityExist(vehicle) then
			if distanceToVeh <= lockDistance then
				if (islocked == 1)then
				SetVehicleDoorsLocked(vehicle, 2)
				exports['mythic_notify']:DoHudText('inform', "You have locked your ~y~" .. GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))) .. "~w~.")
				TriggerEvent('lockLights')
				else
				SetVehicleDoorsLocked(vehicle,1)
				exports['mythic_notify']:DoHudText('inform', "You have unlocked your ~y~" .. GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))) .. "~w~.")
				TriggerEvent('lockLights')
				end
			else
				exports['mythic_notify']:DoHudText('inform', "~r~You must be near your vehicle to do that.")
			end
		else
			exports['mythic_notify']:DoHudText('inform', "~r~No saved vehicle.")
		end
	end)


-- S A V E --
RegisterNetEvent('save')
AddEventHandler('save',function() 
	local player = GetPlayerPed(-1)
	if (IsPedSittingInAnyVehicle(player)) then 
		if  saved == true then
			--remove from saved.
			saveVehicle = nil
			RemoveBlip(targetBlip)
			exports['mythic_notify']:DoHudText('inform', "Saved vehicle ~r~removed~w~.")
			saved = false
		else
			RemoveBlip(targetBlip)
			saveVehicle = GetVehiclePedIsIn(player,false)
			local vehicle = saveVehicle
			targetBlip = AddBlipForEntity(vehicle)
			SetBlipSprite(targetBlip,225)
			exports['mythic_notify']:DoHudText('inform', "This ~y~" .. GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))) .. "~w~ is now your~g~ saved ~w~vehicle.")
			saved = true
		end
	end
end)
-- R E M O T E --
RegisterNetEvent('controlsave')
AddEventHandler('controlsave',function() 
		if controlsave_bool == false then
			controlsave_bool = true
			if saveVehicle == nil then
			exports['mythic_notify']:DoHudText('inform', "~r~No saved vehicle.")
			else
			exports['mythic_notify']:DoHudText('inform', "You are no longer controlling your ~y~" .. GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(saveVehicle))))
			end
		else
			controlsave_bool = false
			if saveVehicle == nil then
			exports['mythic_notify']:DoHudText('inform', "~r~No saved vehicle.")
			else
			exports['mythic_notify']:DoHudText('inform', "You are no longer controlling your ~y~" .. GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(saveVehicle))))
			end
		end
end)

--[[------------------------------------------------------------------------

	ActionMenu - v1.0.1
	Created by WolfKnight
	Additional help from lowheartrate, TheStonedTurtle, and Briglair. 

------------------------------------------------------------------------]]--

-- Define the variable used to open/close the menu 
local menuEnabled = false 

--[[------------------------------------------------------------------------
	ActionMenu Toggle
	Calling this function will open or close the ActionMenu. 
------------------------------------------------------------------------]]--
function ToggleActionMenu()
	-- Make the menuEnabled variable not itself 
	-- e.g. not true = false, not false = true 
	menuEnabled = not menuEnabled
		
	if ( menuEnabled ) then 
		-- Focuses on the NUI, the second parameter toggles the 
		-- onscreen mouse cursor. 
		SetNuiFocus( true, true )

		-- Sends a message to the JavaScript side, telling it to 
		-- open the menu. 
		SendNUIMessage({
			showmenu = true 
		})
	else 
		-- Bring the focus back to the game
		SetNuiFocus( false )

		-- Sends a message to the JavaScript side, telling it to
		-- close the menu.
		SendNUIMessage({
			hidemenu = true 
		})
	end
end 


--[[------------------------------------------------------------------------
	ActionMenu HTML Callbacks
	This will be called every single time the JavaScript side uses the
	sendData function. The name of the data-action is passed as the parameter
	variable data. 
------------------------------------------------------------------------]]--

local windowup = true
RegisterNetEvent("RollWindow")
AddEventHandler('RollWindow', function()
    local playerPed = GetPlayerPed(-1)
    if IsPedInAnyVehicle(playerPed, false) then
        local playerCar = GetVehiclePedIsIn(playerPed, false)
        if ( GetPedInVehicleSeat( playerCar, -1 ) == playerPed ) then 
            SetEntityAsMissionEntity( playerCar, true, true )
        
            if ( windowup ) then
                RollDownWindow(playerCar, 0)
                RollDownWindow(playerCar, 1)
                windowup = false
            else
                RollUpWindow(playerCar, 0)
                RollUpWindow(playerCar, 1)
                windowup = true
            end
        end
    end
end )

RegisterNetEvent('10:13:setblip')
AddEventHandler('10:13:setblip', function()
	local playerPed = PlayerPedId()
	PedPosition		= GetEntityCoords(playerPed)
	local PlayerCoords = { x = PedPosition.x, y = PedPosition.y, z = PedPosition.z }
	TriggerServerEvent('esx_addons_gcphone:startCall', 'police', '10-13 Officer Down at Coords : ', PlayerCoords, {

		PlayerCoords = { x = PedPosition.x, y = PedPosition.y, z = PedPosition.z },
	})
	TriggerServerEvent('InteractSound_SV:PlayOnSource', 'polalert', 1.0)
end)

RegisterCommand("rollw", function(source, args, raw)
    TriggerEvent("RollWindow")
end, false)

RegisterNetEvent('arrest:Anim')
AddEventHandler('arrest:Anim', function()
	while not HasAnimDictLoaded('mp_arrest_paired') do
		Citizen.Wait(100)
	end
	TaskPlayAnim(GetPlayerPed(-1), "mp_arrest_paired", "cop_p2_back_right", 8.0, -8, 4000, 48, 0, 0, 0, 0)
end)


RegisterNUICallback( "ButtonClick", function( data, cb ) 
	if ( data == "button2" ) then 
		TriggerEvent("engine")
	elseif ( data == "button3" ) then 
		TriggerEvent("hood")
	elseif ( data == "button4" ) then 
		TriggerEvent("trunk")
	elseif ( data == 'button5') then
		TriggerEvent("fdoors")
	elseif ( data == "button6" ) then 
		TriggerEvent("rdoors")
	elseif ( data == "button1" ) then 
		TriggerEvent("engine")
		TriggerEvent("hood")
		TriggerEvent("trunk")
		TriggerEvent("fdoors")
		TriggerEvent("rdoors")
	elseif (data == "button7") then 
		TriggerEvent( "RollWindow" )
	elseif (data == "button8") then 
		TriggerEvent( "sswap4" )
	elseif (data == "button10") then 
		TriggerEvent( "sswap2" )
	elseif (data == "button11") then 
		TriggerEvent( "sswap3" )
	elseif (data == "button9") then 
		TriggerEvent( "sswap1" )
	elseif (data == "button12") then 
		TriggerEvent( "sswap5" )
	elseif (data == 'button13') and ESX.GetPlayerData().job.name == 'police' then
		TriggerServerEvent('10:13')
	elseif (data == 'button14') then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 2.0 then
			TriggerServerEvent('esx_policejob:handcuffAsCiv', GetPlayerServerId(closestPlayer))
		end
	elseif (data == 'button15') then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 2.0 then
			TriggerServerEvent('esx_ambulancejob:drag', GetPlayerServerId(closestPlayer))
		end
	elseif (data == 'button16') then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 2.0 then
			TriggerServerEvent('esx_policejob:putInVehicle', GetPlayerServerId(closestPlayer))
		end
	elseif (data == 'button17') then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 2.0 then
			TriggerServerEvent('esx_policejob:OutVehicle', GetPlayerServerId(closestPlayer))
		end
	elseif (data == 'button18') then
		local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
		if closestPlayer ~= -1 and closestDistance <= 2.0 then
			TriggerServerEvent('esx_policejob:drag', GetPlayerServerId(closestPlayer))
		end
	elseif ( data == "exit" ) then 
		-- We toggle the ActionMenu and return here, otherwise the function 
		-- call below would be executed too, which would just open the menu again 
		ToggleActionMenu()
		return 
	end 

	-- This will only be called if any button other than the exit button is pressed
	ToggleActionMenu()
end)


--[[------------------------------------------------------------------------
	ActionMenu Control and Input Blocking 
	This is the main while loop that opens the ActionMenu on keypress. It 
	uses the input blocking found in the ES Banking resource, credits to 
	the authors.
------------------------------------------------------------------------]]--
Citizen.CreateThread( function()
	-- This is just in case the resources restarted whilst the NUI is focused. 
	SetNuiFocus( false )

	while true do 
		-- Control ID 20 is the 'Z' key by default 
		-- Use https://wiki.fivem.net/wiki/Controls to find a different key 
		if ( IsControlJustPressed( 1, 243 ) ) then 
			ToggleActionMenu()
		end 

	    if ( menuEnabled ) then
            local ped = GetPlayerPed( -1 )	

            DisableControlAction( 0, 1, true ) -- LookLeftRight
            DisableControlAction( 0, 2, true ) -- LookUpDown
            DisableControlAction( 0, 24, true ) -- Attack
            DisablePlayerFiring( ped, true ) -- Disable weapon firing
            DisableControlAction( 0, 142, true ) -- MeleeAttackAlternate
            DisableControlAction( 0, 106, true ) -- VehicleMouseControlOverride
        end

		Citizen.Wait( 0 )
	end 
end )

function chatPrint( msg )
	TriggerEvent( 'chatMessage', "ActionMenu", { 255, 255, 255 }, msg )
end 