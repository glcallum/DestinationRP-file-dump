Config                        = {}
Config.DrawDistance           = 100
Config.MarkerSize             = {x = 1.5, y = 1.5, z = 1.0}
Config.MarkerColor            = {r = 50, g = 100, b = 255}
Config.RoomMenuMarkerColor    = {r = 102, g = 204, b = 102}
Config.MarkerType             = 1
Config.Zones                  = {}
Config.Properties             = {}
Config.EnablePlayerManagement = true -- If set to true you need esx_realestateagentjob
Config.Locale                 = 'en'

Config.Properties             = {}
