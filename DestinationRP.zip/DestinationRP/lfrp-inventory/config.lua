Config = {}

Config.OpenControl = 289
Config.TrunkOpenControl = 47

Config.Shops = {
    ['Shop'] = {
        coords = vector3(373.875,   325.896,  102.566 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop2'] = {
        coords = vector3(2557.458,  382.282,  107.622 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop3'] = {
        coords = vector3(-3038.939, 585.954,  6.908 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop4'] = {
        coords = vector3(-3241.927, 1001.462, 11.830 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop5'] = {
        coords = vector3(547.431,   2671.710, 41.156 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop6'] = {
        coords = vector3(1961.464,  3740.672, 31.343 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop7'] = {
        coords = vector3(2678.916,  3280.671, 54.241 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop8'] = {
        coords = vector3(1729.216,  6414.131, 34.037 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop9'] = {
        coords = vector3(-48.519,   -1757.514, 28.421 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop10'] = {
        coords = vector3(1163.373,  -323.801,  68.205 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop11'] = {
        coords = vector3(-707.501,  -914.260,  18.215 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop12'] = {
        coords = vector3(-1820.523, 792.518,   137.118 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop13'] = {
        coords = vector3(1698.388,  4924.404,  41.063 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Shop14'] = {
        coords = vector3(22.09,   -1107.00,  29.80),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop15'] = {
        coords = vector3(252.19,   -50.38,  69.94),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop16'] = {
        coords = vector3(-661.93,   -934.83,  21.83),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop17'] = {
        coords = vector3(810.09,   -2157.68,  29.62),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop18'] = {
        coords = vector3(1693.47,   3759.54,  34.71),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop19'] = {
        coords = vector3(-330.20,   6083.80,  31.45),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop20'] = {
        coords = vector3(2567.56,   294.30,  108.73),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop21'] = {
        coords = vector3(-1117.50,   2698.48,  18.55),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop22'] = {
        coords = vector3(842.32,   -1033.64,  28.19),
job = 'all',
        items = {
            {name = 'WEAPON_PISTOL', price = 350, count = 1},
            {name = 'WEAPON_FLASHLIGHT', price = 15, count = 1},
            {name = 'WEAPON_MACHETE', price = 45, count = 1},
            {name = 'WEAPON_BAT', price = 10, count = 1},
            {name = 'WEAPON_STUNGUN', price = 100, count = 1},
            {name = 'WEAPON_PUMPSHOTGUN', price = 1500, count = 1},
            {name = 'WEAPON_BALL', price = 5, count = 1},
        }
    },
    ['Shop23'] = {
        coords = vector3(1677.65, 4881.955, 42.034),
job = 'all',
        items = {
            {name = 'tomato_seed', price = 14, count = 1},
            {name = 'blueberry_seed', price = 18, count = 1},
            {name = 'plantpot', price = 120, count = 1},
            {name = 'wateringcan', price = 68, count = 1},
            {name = 'lowgradefert', price = 140, count = 1},
            {name = 'highgradefert', price = 260, count = 1},
        }
    },
    ['Shop24'] = {
        coords = vector3(-580.878, -984.902, 22.454),
job = 'all',
        items = {
            {name = 'tomato_seed', price = 14, count = 1},
            {name = 'blueberry_seed', price = 18, count = 1},
            {name = 'plantpot', price = 120, count = 1},
            {name = 'wateringcan', price = 68, count = 1},
            {name = 'lowgradefert', price = 140, count = 1},
            {name = 'highgradefert', price = 260, count = 1},
        }
    },
    ['Shop25'] = {
        coords = vector3(-51.419, 6360.17, 31.454),
job = 'all',
        items = {
            {name = 'tomato_seed', price = 14, count = 1},
            {name = 'blueberry_seed', price = 18, count = 1},
            {name = 'plantpot', price = 120, count = 1},
            {name = 'wateringcan', price = 68, count = 1},
            {name = 'lowgradefert', price = 140, count = 1},
            {name = 'highgradefert', price = 260, count = 1},
        }
    },
    ['Robs Liquor'] = {
        coords = vector3(1135.808,  -982.281,  45.415 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor2'] = {
        coords = vector3(-1222.915, -906.983,  11.326 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor3'] = {
        coords = vector3(-1487.553, -379.107,  39.163 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor4'] = {
        coords = vector3(-2968.243, 390.910,   14.043 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor5'] = {
        coords = vector3(1166.024,  2708.930,  37.157 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor6'] = {
        coords = vector3(1392.562,  3604.684,  33.980 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor7'] = {
        coords = vector3(127.830,   -1284.796, 28.280 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor8'] = {
        coords = vector3(-1393.409, -606.624,  29.319 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Robs Liquor9'] = {
        coords = vector3(-559.906,  287.093,   81.176 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1},
            {name = 'cocacola', price = 3, count = 1},
            {name = 'citizencard', price = 5, count = 1},
            {name = 'chocolate', price = 3, count = 1},
            {name = 'energy', price = 4, count = 1},
            {name = 'hamburger', price = 5, count = 1},
            {name = 'binoculars', price = 50, count = 1},
            {name = 'phone', price = 100, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'notepad', price = 20, count = 1},
            {name = 'radio', price = 150, count = 1},
        }
    },
    ['Mega Mall'] = {
        coords = vector3(46.68, -1749.77, 29.00 + 1),
job = 'all',
        items = {
            {name = 'handcuffs', price = 300, count = 1},
            {name = 'rope', price = 500, count = 1},
            {name = 'key', price = 10, count = 1},
            {name = 'bandage', price = 15, count = 1},
            {name = 'lockpick', price = 550, count = 1},
            {name = 'rasperry', price = 6000, count = 1},
            {name = 'blowtorch', price = 1500, count = 1},
            {name = 'HeavyArmor', price = 250, count = 1},
            {name = 'sgAmmo', price = 65, count = 1},
            {name = 'pAmmo', price = 80, count = 1},
        }
    },
    ['Fishing Shack'] = {
        coords = vector3(55.11, -1739.35, 29.00 + 1),
job = 'all',
        items = {
            {name = 'fishingrod', price = 75, count = 1},
            {name = 'turtlebait', price = 50, count = 1},
            {name = 'fishbait', price = 3, count = 1}
        }
    },
    ['PD Shop'] = {
        coords = vector3(457.88, -993.35, 29.50 + 1),
job = 'police',
        items = {
            {name = 'WEAPON_CARBINERIFLE', price = 0, count = 1},
            {name = 'WEAPON_STUNGUN', price = 0, count = 1},
            {name = 'WEAPON_COMBATPISTOL', price = 0, count = 1},
            {name = 'WEAPON_PISTOL_MK2', price = 0, count = 1},
            {name = 'WEAPON_NIGHTSTICK', price = 0, count = 1},
            {name = 'WEAPON_SMG', price = 0, count = 1},
            {name = 'HeavyArmor', price = 0, count = 1},
            {name = 'pAmmo', price = 0, count = 1},
            {name = 'sgAmmo', price = 0, count = 1},
            {name = 'arAmmo', price = 0, count = 1},
            {name = 'mgAmmo', price = 0, count = 1},
        }
    },
    ['Drug Dealer'] = {
        coords = vector3(144.80, -2203.94, 4.00 + 1),
job = 'all',
        items = {
            {name = 'crack', price = 350, count = 1},
            {name = 'vicodin', price = 265, count = 1},
        }
    },
    ['Hospital'] = {
        coords = vector3(316.81, -588.19, 42.29 + 1),
job = 'all',
        items = {
            {name = 'hydrocodone', price = 400, count = 1},
            {name = 'firstaid', price = 80, count = 1},
            {name = 'gauze', price = 50, count = 1},
            {name = 'bandaids', price = 15, count = 1},
        }
    },
    ['Tuning Shop'] = {
        coords = vector3(994.04, -2988.39, -39.65),
job = 'all',
        items = {
            {name = 'tunerchip', price = 50000, count = 1},
            {name = 'fixkit', price = 2000, count = 1},
            {name = 'fixkit2', price = 1000, count = 1},
            {name = 'fixkit3', price = 500, count = 1},
            {name = 'fixkit4', price = 1500, count = 1},
        }
    },
    ['Prison Shop'] = {
        coords = vector3(997.79, -3092.06, -39.00 + 1),
job = 'all',
        items = {
            {name = 'bread', price = 2, count = 1},
            {name = 'water', price = 2, count = 1},
            {name = 'chips', price = 1, count = 1}
        }
    }
}

Config.Stash = {
    --[[['Evidence Locker'] = {
        coords = vector3(480.58, -989.24, 24.91),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'police',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },]]--
    ['Stash'] = {
        coords = vector3(1374.20, -616.42, 57.01),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash2'] = {
        coords = vector3(1348.20, -607.21, 57.00),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash3'] = {
        coords = vector3(1392.95, -603.45, 56.78),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash5'] = {
        coords = vector3(1396.24, -579.64, 56.78),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash6'] = {
        coords = vector3(1380.18, -566.01, 56.98),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash7'] = {
        coords = vector3(1355.32, -556.88, 56.19),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash8'] = {
        coords = vector3(1335.48, -546.00, 54.74),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash9'] = {
        coords = vector3(1310.12, -537.56, 53.76),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash10'] = {
        coords = vector3(1308.01, -584.65, 54.03),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash11'] = {
        coords = vector3(1330.19, -593.01, 55.54),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash12'] = {
        coords = vector3(-34.63, -1844.19, 8.84),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash13'] = {
        coords = vector3(-21.07, -1855.83, 7.94),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash14'] = {
        coords = vector3(-5.51, -1869.13, 6.84),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash15'] = {
        coords = vector3(4.55, -1881.30, 6.34),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash16'] = {
        coords = vector3(22.74, -1893.51, 5.64),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash17'] = {
        coords = vector3(38.61, -1908.49, 4.64),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash18'] = {
        coords = vector3(56.01, -1919.55, 4.25),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash19'] = {
        coords = vector3(71.68, -1936.11, 3.71),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash20'] = {
        coords = vector3(75.70, -1944.98, 3.51),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash21'] = {
        coords = vector3(85.30, -1956.71, 3.46),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash22'] = {
        coords = vector3(113.74, -1958.20, 3.67),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash23'] = {
        coords = vector3(126.18, -1927.23, 3.72),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash24'] = {
        coords = vector3(117.89, -1918.10, 3.66),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash25'] = {
        coords = vector3(100.40, -1909.17, 3.75),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash26'] = {
        coords = vector3(53.74, -1870.37, 5.34),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash27'] = {
        coords = vector3(45.15, -1861.45, 5.84),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash28'] = {
        coords = vector3(29.36, -1851.32, 6.54),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash29'] = {
        coords = vector3(20.63, -1841.42, 7.34),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash30'] = {
        coords = vector3(1105.63, 2655.90, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash32'] = {
        coords = vector3(1106.68, 2644.62, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash33'] = {
        coords = vector3(1114.13, 2644.67, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash34'] = {
        coords = vector3(1120.86, 2644.73, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash35'] = {
        coords = vector3(1124.62, 2644.71, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash36'] = {
        coords = vector3(1132.15, 2644.65, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash37'] = {
        coords = vector3(1135.84, 2644.49, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash38'] = {
        coords = vector3(1140.69, 2644.67, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash39'] = {
        coords = vector3(1141.79, 2646.57, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash40'] = {
        coords = vector3(1141.88, 2657.77, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
    ['Stash41'] = {
        coords = vector3(1141.85, 2654.26, 20.48),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'all',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },

}

Config.Evidence = {
    ['Evidence Locker'] = {
        coords = vector3(480.58, -989.24, 24.91),
        size = vector3(0.5, 0.5, 0.0),
        markerColour = { r = 255, g = 255, b = 255 },
        job = 'police',
        msg = 'Open Stash ~INPUT_CONTEXT~'
    },
}

Config.Steal = {
    black_money = true,
    cash = true
}

Config.Seize = {
    black_money = true,
    cash = true
}

Config.VehicleSlot = {
    [0] = 10, --Compact
    [1] = 15, --Sedan
    [2] = 20, --SUV
    [3] = 15, --Coupes
    [4] = 10, --Muscle
    [5] = 10, --Sports Classics
    [6] = 5, --Sports
    [7] = 2, --Super
    [8] = 3, --Motorcycles
    [9] = 10, --Off-road
    [10] = 25, --Industrial
    [11] = 25, --Utility
    [12] = 30, --Vans
    [13] = 0, --Cycles
    [14] = 0, --Boats
    [15] = 0, --Helicopters
    [16] = 0, --Planes
    [17] = 20, --Service
    [18] = 20, --Emergency
    [19] = 15, --Military
    [20] = 50, --Commercial
    [21] = 0 --Trains
}