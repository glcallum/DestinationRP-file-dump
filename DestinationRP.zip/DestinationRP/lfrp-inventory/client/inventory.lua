secondInventory = nil

RegisterNUICallback('MoveToEmpty', function(data)
    TriggerServerEvent('lfrp-inventory:MoveToEmpty', data)
    TriggerEvent('lfrp-inventory:MoveToEmpty', data)
end)

RegisterNUICallback('EmptySplitStack', function(data)
    TriggerServerEvent('lfrp-inventory:EmptySplitStack', data)
    TriggerEvent('lfrp-inventory:EmptySplitStack', data)
end)

RegisterNUICallback('SplitStack', function(data)
    TriggerServerEvent('lfrp-inventory:SplitStack', data)
    TriggerEvent('lfrp-inventory:SplitStack', data)
end)

RegisterNUICallback('CombineStack', function(data)
    TriggerServerEvent('lfrp-inventory:CombineStack', data)
    TriggerEvent('lfrp-inventory:CombineStack', data)
end)

RegisterNUICallback('SwapItems', function(data)
    TriggerServerEvent('lfrp-inventory:SwapItems', data)
    TriggerEvent('lfrp-inventory:SwapItems', data)
end)

RegisterNUICallback('GiveItem', function(data, cb)
    TriggerServerEvent('lfrp-inventory:notifyImpendingRemoval', data.item, data.number)
    TriggerServerEvent('lfrp-inventory:GiveItem', data)
    cb('OK')
end)

RegisterNUICallback('GiveCash', function(data, cb)
    TriggerServerEvent('lfrp-inventory:GiveCash', data)
    RequestAnimDict('mp_common')
    while not HasAnimDictLoaded('mp_common') do
        Citizen.Wait(5)
    end
    TaskPlayAnim(PlayerPedId(), "mp_common", "givetake1_a", 8.0, -8, -1, 12, 1, 0, 0, 0)
    cb('OK')
end)

RegisterNUICallback('GetNearPlayers', function(data)

    if data.action == 'give' then
        SendNUIMessage({
            action = "nearPlayersGive",
            players = GetNeareastPlayers(),
            item = data.item
        })
    end

    if data.action == 'pay' then
        SendNUIMessage({
            action = "nearPlayersPay",
            players = GetNeareastPlayers(),
            item = data.item
        })
    end
end)

function GetNeareastPlayers()
    local playerPed = PlayerPedId()
    local players, nearbyPlayer = ESX.Game.GetPlayersInArea(GetEntityCoords(playerPed), 2.0)

    local players_clean = {}
    local found_players = false

    for i = 1, #players, 1 do
        if players[i] ~= PlayerId() then
            found_players = true
            table.insert(players_clean, { name = GetPlayerName(players[i]), id = GetPlayerServerId(players[i]) })
        end
    end
    return players_clean
end

RegisterNetEvent('lfrp-inventory:refreshInventory')
AddEventHandler('lfrp-inventory:refreshInventory', function()
    refreshPlayerInventory()
    if secondInventory ~= nil then
        refreshSecondaryInventory()
    end
end)

function refreshPlayerInventory()
    ESX.TriggerServerCallback('lfrp-inventory:getPlayerInventory', function(data)
        SendNUIMessage(
                { action = "setItems",
                  itemList = data.inventory,
                  invOwner = data.invId,
                  invTier = data.invTier,
                  money = {
                      cash = data.cash,
                      bank = data.bank,
                      black_money = data.black_money
                  }
                }
        )
        TriggerServerEvent('lfrp-inventory:openInventory', {
            type = 'player',
            owner = ESX.GetPlayerData().identifier
        })
    end, 'player', ESX.GetPlayerData().identifier)
end

function refreshSecondaryInventory()
    ESX.TriggerServerCallback('lfrp-inventory:getSecondaryInventory', function(data)
        SendNUIMessage(
                { action = "setSecondInventoryItems",
                  itemList = data.inventory,
                  invOwner = data.invId,
                  invTier = data.invTier,
                }
        )
        TriggerServerEvent('lfrp-inventory:openInventory', secondInventory)
    end, secondInventory.type, secondInventory.owner)
end

function closeInventory()
    isInInventory = false
    SendNUIMessage({ action = "hide" })
    SetNuiFocus(false, false)
    TransitionFromBlurred(1000)
    TriggerServerEvent('lfrp-inventory:closeInventory', {
        type = 'player',
        owner = ESX.GetPlayerData().identifier
    })
    if secondInventory ~= nil then
        TriggerServerEvent('lfrp-inventory:closeInventory', secondInventory)
    end
end

RegisterNetEvent('lfrp-inventory:openInventory')
AddEventHandler('lfrp-inventory:openInventory', function(sI)
    openInventory(sI)
end)

function openInventory(_secondInventory)
    isInInventory = true
    refreshPlayerInventory()
    SendNUIMessage({
        action = "display",
        type = "normal"
    })
    if _secondInventory ~= nil then
        secondInventory = _secondInventory
        refreshSecondaryInventory()
        SendNUIMessage({
            action = "display",
            type = 'secondary'
        })
        if _secondInventory.seize then
            SendNUIMessage({
                action = "showSeize"
            })
        end
        if _secondInventory.steal then
            SendNUIMessage({
                action = "showSteal"
            })
        end
    end
    TransitionToBlurred(1000)
    SetNuiFocus(true, true)
end

RegisterNetEvent("lfrp-inventory:MoveToEmpty")
AddEventHandler("lfrp-inventory:MoveToEmpty", function(data)
    playPickupOrDropAnimation(data)
end)

RegisterNetEvent("lfrp-inventory:EmptySplitStack")
AddEventHandler("lfrp-inventory:EmptySplitStack", function(data)
    playPickupOrDropAnimation(data)
end)

RegisterNetEvent("lfrp-inventory:SplitStack")
AddEventHandler("lfrp-inventory:SplitStack", function(data)
    playPickupOrDropAnimation(data)
end)

RegisterNetEvent("lfrp-inventory:CombineStack")
AddEventHandler("lfrp-inventory:CombineStack", function(data)
    playPickupOrDropAnimation(data)
end)

RegisterNetEvent("lfrp-inventory:SwapItems")
AddEventHandler("lfrp-inventory:SwapItems", function(data)
    playPickupOrDropAnimation(data)
end)

function playPickupOrDropAnimation(data)
    if data.originTier.name == 'drop' or data.destinationTier.name == 'drop' then
        local playerPed = GetPlayerPed(-1)
        if not IsEntityPlayingAnim(playerPed, 'random@domestic', 'pickup_low', 3) then
            ESX.Streaming.RequestAnimDict('random@domestic', function()
                TaskPlayAnim(playerPed, 'random@domestic', 'pickup_low', 8.0, -8, -1, 48, 0, 0, 0, 0)
            end)
        end
    end
end