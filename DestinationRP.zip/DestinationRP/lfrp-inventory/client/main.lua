ESX = nil
Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj)
            ESX = obj
        end)
        Citizen.Wait(0)
    end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(10)
    end

    ESX.PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    ESX.PlayerData.job = job
end)

Citizen.CreateThread(function()

    for k,v in pairs(Config.Shops) do
        local blip = AddBlipForCoord(v.coords)
        if v.coords == vector3(997.79, -3092.06, -39.00 + 1) or v.coords == vector3(994.04, -2988.39, -39.65 + 1) or v.coords == vector3(144.80, -2203.94, 4.00 + 1) or v.coords == vector3(457.88, -993.35, 29.50 + 1) or v.coords == vector3(316.81, -588.19, 42.29 + 1) or v.coords == vector3(22.09,   -1107.00,  29.80) or v.coords == vector3(252.19,   -50.38,  69.94) or v.coords == vector3(-661.93,   -934.83,  21.83) or v.coords == vector3(810.09,   -2157.68,  29.62) or v.coords == vector3(1693.47,   3759.54,  34.71) or v.coords == vector3(-330.20,   6083.80,  31.45) or v.coords == vector3(2567.56,   294.30,  108.73) or v.coords ==  vector3(-1117.50,   2698.48,  18.55) or v.coords == vector3(842.32,   -1033.64,  28.19) then
            RemoveBlip(blip)
        else
        

		SetBlipSprite (blip, 52)
		SetBlipDisplay(blip, 4)
		SetBlipScale  (blip, 0.8)
		SetBlipColour (blip, 2)
		SetBlipAsShortRange(blip, true)

		BeginTextCommandSetBlipName("STRING")
		AddTextComponentString("Shop")
        EndTextCommandSetBlipName(blip)
        end
	end

end)

Citizen.CreateThread(function()
    for k,v in pairs(Config.Shops) do
        local blip = AddBlipForCoord(v.coords)
        if v.coords == vector3(22.09,   -1107.00,  29.80) or v.coords == vector3(252.19,   -50.38,  69.94) or v.coords == vector3(-661.93,   -934.83,  21.83) or v.coords == vector3(810.09,   -2157.68,  29.62) or v.coords == vector3(1693.47,   3759.54,  34.71) or v.coords == vector3(-330.20,   6083.80,  31.45) or v.coords == vector3(2567.56,   294.30,  108.73) or v.coords ==  vector3(-1117.50,   2698.48,  18.55) or v.coords == vector3(842.32,   -1033.64,  28.19) then

            SetBlipSprite (blip, 110)
			SetBlipDisplay(blip, 4)
			SetBlipScale  (blip, 1.0)
			SetBlipColour (blip, 81)
			SetBlipAsShortRange(blip, true)

			BeginTextCommandSetBlipName("STRING")
			AddTextComponentSubstringPlayerName('Weapon Shop')
			EndTextCommandSetBlipName(blip)
        else
            RemoveBlip(blip)
        end
    end
end)

local dropSecondaryInventory = {
    type = 'drop',
    owner = 'x123y123z123'
}

local isInInventory = false

RegisterNUICallback('NUIFocusOff', function(data)
    closeInventory()
end)

RegisterCommand('closeinv', function(source, args, raw)
    closeInventory()
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsControlJustReleased(0, Config.OpenControl) and IsInputDisabled(0) then
            local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1)))
            local _, floorZ = GetGroundZFor_3dCoord(x, y, z)
            dropSecondaryInventory.owner = getOwnerFromCoords(vector3(x, y, floorZ))
            openInventory(dropSecondaryInventory)
        end
        if IsControlJustReleased(0, 73) then
            SetCurrentPedWeapon(GetPlayerPed(-1), GetHashKey('WEAPON_UNARMED'), true)
        end
    end
end
)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        closeInventory()
    end
end)




