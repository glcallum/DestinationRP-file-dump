local secondarySearchInventory = {
    type = 'player',
    owner = '',
    seize = true
}
local secondaryStealInventory = {
    type = 'player',
    owner = '',
    steal = true
}

RegisterNetEvent('lfrp-inventory:search')
AddEventHandler('lfrp-inventory:search', function()
    print('Searching')
    local player = ESX.GetPlayerData()
    if player.job.name == 'police' then
        local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
        if closestPlayer ~= -1 and closestDistance <= 3.0 then
            local searchPlayerPed = GetPlayerPed(closestPlayer)
            ESX.TriggerServerCallback('lfrp-inventory:getIdentifier', function(identifier)
                secondarySearchInventory.owner = identifier
                openInventory(secondarySearchInventory)
            end, GetPlayerServerId(closestPlayer))
        end
    end
end)

RegisterNetEvent('lfrp-inventory:steal')
AddEventHandler('lfrp-inventory:steal', function()
    local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
    RequestAnimDict("random@shop_robbery")
    while not HasAnimDictLoaded("random@shop_robbery") do
        Citizen.Wait(0)
	end
    if closestPlayer ~= -1 and closestDistance <= 3.0 then
        local searchPlayerPed = GetPlayerPed(closestPlayer)
        if ( IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "dead", "dead_a", 3) or IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "amb@code_human_cower_stand@male@base", "base", 3) or IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "amb@code_human_cower@male@base", "base", 3) or IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "random@arrests@busted", "idle_a", 3) or IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "mp_arresting", "idle", 3) or IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "random@mugging3", "handsup_standing_base", 3) or IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "missfbi5ig_22", "hands_up_anxious_scientist", 3) or IsEntityPlayingAnim(GetPlayerPed(closestPlayer), "missfbi5ig_22", "hands_up_loop_scientist", 3) ) then
            if IsPedArmed(GetPlayerPed(-1), 7) then
                TaskPlayAnim(GetPlayerPed(-1), "random@shop_robbery", "robbery_action_b", 8.0, -8, -1, 16, 0, 0, 0, 0)
                exports["drp_taskbar"]:StartDelayedFunction('Robbing', 3500, function()
                    ESX.TriggerServerCallback('lfrp-inventory:getIdentifier', function(identifier)
                        secondaryStealInventory.owner = identifier
                        openInventory(secondaryStealInventory)
                    end, GetPlayerServerId(closestPlayer))
                    ClearPedTasks(GetPlayerPed(-1))
                end)
            end
        end
    end
end)

RegisterNUICallback('StealCash', function(data)
    TriggerServerEvent('lfrp-inventory:StealCash', data)
end)
RegisterNUICallback('SeizeCash', function(data)
    TriggerServerEvent('lfrp-inventory:SeizeCash', data)
end)