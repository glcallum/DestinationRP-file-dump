
local shopSecondaryInventory = {
    type = 'shop',
    owner = ''
}

Citizen.CreateThread(function()
    while ESX == nil or ESX.PlayerData == nil or ESX.PlayerData.job == nil do
        Citizen.Wait(10)
    end
    print('Shops Working')
    for k, v in pairs(Config.Shops) do
        if v.coords == vector3(22.09,   -1107.00,  29.80) or v.coords == vector3(252.19,   -50.38,  69.94) or v.coords == vector3(-661.93,   -934.83,  21.83) or v.coords == vector3(810.09,   -2157.68,  29.62) or v.coords == vector3(1693.47,   3759.54,  34.71) or v.coords == vector3(-330.20,   6083.80,  31.45) or v.coords == vector3(2567.56,   294.30,  108.73) or v.coords ==  vector3(-1117.50,   2698.48,  18.55) or v.coords == vector3(842.32,   -1033.64,  28.19) then
            local marker1 = {
                name = k,
                type = 1,
                coords = v.coords,
                colour = { r = 255, b = 255, g = 255 },
                size = vector3(0.5, 0.5, 0.0),
                action = function()
                    ESX.TriggerServerCallback('esx_license:checkLicense', function(hasWeaponLicense)
                        if hasWeaponLicense then
                            shopSecondaryInventory.owner = k
                            openInventory(shopSecondaryInventory)
                        else
                            exports['mythic_notify']:DoHudText('error', "You do not have a Weapon's License. Contact the Police.")
                        end
                    end, GetPlayerServerId(PlayerId()), 'weapon')
                end,
                shouldDraw = function()
                    return ESX.PlayerData.job.name == v.job or v.job == 'all'
                end,
                msg = 'Press ~INPUT_CONTEXT~ to open Weapon Shop',
            }
            TriggerEvent('disc-base:registerMarker', marker1)
        else
            local marker = {
                name = k,
                type = 1,
                coords = v.coords,
                colour = { r = 255, b = 255, g = 255 },
                size = vector3(0.5, 0.5, 0.0),
                action = function()
                    shopSecondaryInventory.owner = k
                    openInventory(shopSecondaryInventory)
                end,
                shouldDraw = function()
                    return ESX.PlayerData.job.name == v.job or v.job == 'all'
                end,
                msg = 'Press ~INPUT_CONTEXT~ to open Weapon Shop',
            }
            TriggerEvent('disc-base:registerMarker', marker)
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local player = GetPlayerPed(-1)
        local coords = GetEntityCoords(player)
        for k, v in pairs(Config.Shops) do
            if v.coords == vector3(22.09,   -1107.00,  29.80) or v.coords == vector3(252.19,   -50.38,  69.94) or v.coords == vector3(-661.93,   -934.83,  21.83) or v.coords == vector3(810.09,   -2157.68,  29.62) or v.coords == vector3(1693.47,   3759.54,  34.71) or v.coords == vector3(-330.20,   6083.80,  31.45) or v.coords == vector3(2567.56,   294.30,  108.73) or v.coords ==  vector3(-1117.50,   2698.48,  18.55) or v.coords == vector3(842.32,   -1033.64,  28.19) then
                if GetDistanceBetweenCoords(coords, v.coords, true) < 3.0 then
                    ESX.Game.Utils.DrawText3D(vector3(v.coords), "[E] - Open Weapon Shop", 0.6)
                end
            else
                if GetDistanceBetweenCoords(coords, v.coords, true) < 3.0 then
                    ESX.Game.Utils.DrawText3D(vector3(v.coords), "[E] - Open Shop", 0.6)
                end
            end
        end
    end
end)