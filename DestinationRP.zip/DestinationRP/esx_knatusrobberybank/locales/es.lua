Locales['es'] = {

	['robbery_cancelled'] = 'El atraco se canceló, ¡No ganarás nada!',
	['robbery_successful'] = 'Atraco exitoso, has ganado! ~g~$',
	['bank_robbery'] = 'Robo al banco',
	['press_to_rob'] = 'Presiona ~INPUT_CONTEXT~ para robar ~b~',
	['press_to_cancel'] = 'Presiona ~INPUT_CONTEXT~ para cancelar el robo ~b~',
	['press_to_hack'] = 'Presiona ~INPUT_CONTEXT~ para hackear ~b~',
	['press_to_bomb'] = '¡Presiona ~INPUT_CONTEXT~ para plantar la bomba en la puerta! ~b~',
	['robbery_of'] = 'robo al banco: ~r~',
	['hack_of'] = 'hackeando el banco: ~r~',
	['seconds_remaining'] = '~w~ segundos restantes',
	['robbery_cancelled_at'] = '~r~ Atraco cancelado en: ~b~',
	['robbery_has_cancelled'] = '~r~ El atraco ha sido cancelado: ~b~',
	['already_robbed'] = 'Este sitio ya ha sido robado. Por favor espera: ',
	['seconds'] = 'segundos.',
	['rob_in_prog'] = '~r~ Atraco en progreso en: ~b~',
	['started_to_rob'] = 'Has comenzado un atraco ',
	['started_to_hack'] = 'Has comenzado a hackear ',
	['started_to_plantbomb'] = 'Has comenzado a plantar la bomba ',
	['do_not_move'] = ', No te muevas!',
	['alarm_triggered'] = 'Han saltado las alarmas',
	['hold_pos'] = '¡Aguanta 5 minutos y el dinero será tuyo!',
	['hold_pos_hack'] = '¡Aguanta mientras hackeas la puerta de entrada y podrás acceder al interior!',
	['hold_pos_plantbomb'] = '¡Aguanta mientras plantas la bomba, ya estás casi dentro!',
	['leave'] = 'Presiona ~INPUT_CONTEXT~ para salir de ',
	['robbery_complete'] = '~r~ Atraco completado.~s~ ~h~ ¡Corre! ',
	['hack_complete'] = '~r~ Hackeo completado. ¡Ahora robalo, corre! ',
	['robbery_complete_at'] = '~r~ Atraco completado en: ~b~',
	['min_two_police'] = 'Numero de policias necesarios: ',
	['robbery_already'] = '~r~ Ya hay un atraco en progreso.',
	['bombplanted_run'] = 'Has plantado la bomba, ¡corre y cubrete! Explotará en 20 segundos',
	['bombplanted_at'] = '¡Una bomba ha sido plantada en: ~b~ !',
	['rasperry_needed'] = '¡Necesitas una Rasperry para hackear!',
	['c4_needed'] = '¡Necesitas un C4 para abrir esta puerta!',
	['blowtorch_needed'] = '¡Necesitas un soplete para robar los cajones del banco!',

}
