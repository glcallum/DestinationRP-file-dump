ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)
function Drugs1()
	StartScreenEffect("DrugsMichaelAliensFightIn", 3.0, 0)
	Citizen.Wait(5000)
	SetPedMoveRateOverride(PlayerId(), 10.0)
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.49)
	StartScreenEffect("DrugsMichaelAliensFight", 3.0, 0)
	Citizen.Wait(8000)
	StartScreenEffect("DrugsMichaelAliensFightOut", 3.0, 0)
	Citizen.Wait(12000)
	StopScreenEffect("DrugsMichaelAliensFightIn")
	StopScreenEffect("DrugsMichaelAliensFight")
	StopScreenEffect("DrugsMichaelAliensFightOut")

end

function Drugs2()
	StartScreenEffect("DrugsTrevorClownsFightIn", 3.0, 0)
	StartScreenEffect("DrugsTrevorClownsFight", 3.0, 0)
	Citizen.Wait(8000)
	StartScreenEffect("DrugsTrevorClownsFightOut", 3.0, 0)
	Citizen.Wait(8000)
	SetPedMoveRateOverride(PlayerId(), 0.0)
    SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
	Citizen.Wait(100000)
	StopScreenEffect("DrugsTrevorClownsFight")
	StopScreenEffect("DrugsTrevorClownsFightIn")
	StopScreenEffect("DrugsTrevorClownsFightOut")
end

RegisterNetEvent('esx_drugs:onCrack')
AddEventHandler('esx_drugs:onCrack', function()
	RequestAnimDict("mp_suicide")
    while (not HasAnimDictLoaded("mp_suicide")) do Citizen.Wait(0)
    end
	TaskPlayAnim( GetPlayerPed(-1), "mp_suicide", "pill_fp", 8.0, 1.0, 2800, 49, 0, 0, 0, 0 )
	Citizen.Wait(1000)
	Drugs1()
	Drugs2()
end)
