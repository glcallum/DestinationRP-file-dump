Config = {}

Config.MenuKey 			= 182 -- "L" button, change to whatever you want
Config.UseCustomFonts 	= false -- Leave this as is if you don't know how to or haven't loaded custom fonts.
Config.CustomFontFile 	= "greek" -- change only if you turn custom fonts on.
Config.CustomFontId 	= "OpenSans" -- change only if you turn custom fonts ok.
Config.Locale 			= "en" -- gr / en / br

Config.Documents = {}
