local currentHealth = GetEntityHealth(GetPlayerPed(-1))
local lockHealth = GetEntityHealth(GetPlayerPed(-1))
local hunger = 0
local thirst = 0
local pauseHealth = false
ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

RegisterNetEvent('vgn_realhealth:pauseReal')
AddEventHandler('vgn_realhealth:pauseReal', function()
	pauseHealth = true
	Citizen.Wait(2000)
	pauseHealth = false
end)


--Health lock & no regen
Citizen.CreateThread(function()
	while true do
		if pauseHealth == false then
			local currentPed = GetPlayerPed(-1)
			TriggerEvent('esx_status:getStatus', 'hunger', function(status)
				hunger = status.val
			end)
			TriggerEvent('esx_status:getStatus', 'thirst', function(status)
				thirst = status.val
			end)
			Citizen.Wait(300)
			SetPlayerHealthRechargeMultiplier(PlayerId(), 0.0)
		else
			Citizen.Wait(0)
		end
	end
end)
