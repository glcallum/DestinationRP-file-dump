Citizen.CreateThread(function()
	while true do
		SetDiscordAppId(607906304929038346)
		SetDiscordRichPresenceAsset('logo')
        SetDiscordRichPresenceAssetText("Sign up at LividFizzRoleplay.net")
        SetDiscordRichPresenceAssetSmall('info')
		SetDiscordRichPresenceAssetSmallText('https://discord.gg/GNkdrPB')
		Citizen.Wait(1500)
	end
end)
Citizen.CreateThread(function()
	while true do
		local pId = GetPlayerServerId(PlayerId())
		local pName = GetPlayerName(PlayerId())
		local StreetHash = GetStreetNameAtCoord(x, y, z)
		Citizen.Wait(1500)
		players = {}
		for i = 0, 255 do
			if NetworkIsPlayerActive( i ) then
				table.insert( players, i )
			end
		end
		Citizen.Wait(15000)
		SetRichPresence("Eating Toast | " ..#players.."/40")
	end
end)