Locales['en'] = {
  -- regulars
  	['duty'] = 'Press ~INPUT_CONTEXT~ to go ~g~ON~s~/~r~OFF~s~ duty',
	['onduty'] = 'You went on-duty.',
	['offduty'] = 'You went off-duty.',
	['notpol'] = 'You are not a policeman.',
	['notamb'] = 'You are not a doctor.',
}
