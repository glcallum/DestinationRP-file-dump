	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), key, value)
end

Citizen.CreateThread(function()
	-- FBI
	AddTextEntry('0x432EA949', 'FBI')
	-- FBI2
	AddTextEntry('0x9DC66994', 'FBI2')
