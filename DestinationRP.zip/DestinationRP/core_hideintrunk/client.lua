local Keys = {
    ["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
    ["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
    ["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
    ["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
    ["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
    ["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
    ["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
    ["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
    ["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
  }

local player = PlayerPedId()
local inside = false

function DrawText3DTest(x,y,z, text)
	local onScreen,_x,_y=World3dToScreen2d(x,y,z)
	local px,py,pz=table.unpack(GetGameplayCamCoords())
			
	SetTextScale(0.35, 0.35)
	SetTextFont(4)
	SetTextProportional(1)
	SetTextColour(255, 255, 255, 215)
		
	SetTextEntry("STRING")
	SetTextCentre(1)
	AddTextComponentString(text)
	DrawText(_x,_y)
	local factor = (string.len(text)) / 370
	DrawRect(_x,_y+0.0125, 0.015+ factor, 0.03, 41, 11, 41, 68)
end

	Citizen.CreateThread(function()
	  	while true do
		    Citizen.Wait(5)

		    	player = PlayerPedId()
			local plyCoords = GetEntityCoords(player, false)
			local vehicle = VehicleInFront()
			local lockStatus = GetVehicleDoorLockStatus(vehicle)

		    if IsDisabledControlPressed(0, Keys['M']) and GetVehiclePedIsIn(player, false) == 0 and DoesEntityExist(vehicle) and IsEntityAVehicle(vehicle) then    	
				if lockStatus == 4 then
					exports['mythic_notify']:DoHudText('error', 'This vehicle is locked.')
				elseif not inside then
					SetVehicleDoorOpen(vehicle, 5, false, false)
					local d1,d2 = GetModelDimensions(GetEntityModel(vehicle))
		        	AttachEntityToEntity(player, vehicle, 0, -0.1,d1["y"]+0.85,d2["z"]-0.87, 0, 0, 40.0, 1, 1, 1, 1, 1, 1)		       		
		       		RaiseConvertibleRoof(vehicle, false)
					   if IsEntityAttached(player) then
						local testdic = "fin_ext_p1-7"
        				local testanim = "cs_devin_dual-7"
						SetBlockingOfNonTemporaryEvents(player, true)      
        				SetPedSeeingRange(player, 0.0)     
       					SetPedHearingRange(player, 0.0)        
        				SetPedFleeAttributes(player, 0, false)     
        				SetPedKeepTask(player, true)
						ClearPedTasks(player)
						RequestAnimDict('fin_ext_p1-7')
						while not HasAnimDictLoaded('fin_ext_p1-7') do
							Citizen.Wait(100)
						end
        				TaskPlayAnim(player, testdic, testanim, 8.0, 8.0, -1, 1, 999.0, 0, 0, 0)	
		            	if not (IsEntityPlayingAnim(player, 'fin_ext_p1-7', 'cs_devin_dual-7', 3) == 1) then
		          			Streaming('fin_ext_p1-7', function()
					  		TaskPlayAnim(player, 'fin_ext_p1-7', 'cs_devin_dual-7', 1.0, -1, -1, 49, 0, 0, 0, 0)
		               	end)
		            end    
		           	
		    		inside = true 						         		
		    		else
		    		inside = false
		    		end		    	
		    	end
		    	Citizen.Wait(2000)
		    	SetVehicleDoorShut(vehicle, 5, false)    	
		    end
			if DoesEntityExist(vehicle) and IsEntityAVehicle(vehicle) and not inside and GetVehiclePedIsIn(player, false) == 0 then
			elseif DoesEntityExist(vehicle) and inside then
		    		car = GetEntityAttachedTo(player)
		    		carxyz = GetEntityCoords(car, 0)
		   			local visible = true
		   			DisableAllControlActions(0)
		   			DisableAllControlActions(1)
					   DisableAllControlActions(2)
					   EnableControlAction(0, Keys['F'], true)
		   			EnableControlAction(0, 0, true) --- V - camera
		   			EnableControlAction(0, 249, true) --- N - push to talk	
		   			EnableControlAction(2, 1, true) --- camera moving
		   			EnableControlAction(2, 2, true) --- camera moving	
		   			EnableControlAction(0, 177, true) --- BACKSPACE
					   EnableControlAction(0, 200, true) --- ESC
					   local d1,d2 = GetModelDimensions(GetEntityModel(vehicle))
					   local DropPosition = GetOffsetFromEntityInWorldCoords(vehicle, 0.0,d1["y"]-0.2,0.0)
					   
					   DrawText3DTest(DropPosition["x"],DropPosition["y"],DropPosition["z"],"[G] Open/Close | [F] Climb Out")
					
				

					   if IsDisabledControlJustReleased(0,47) then

						if GetVehicleDoorAngleRatio(vehicle, 5) > 0.0 then
							SetVehicleDoorShut(vehicle, 5, 1, true)
							Citizen.Wait(500)
							SetVehicleDoorShut(vehicle, 5, 1, true)
							
						else
							SetVehicleDoorOpen(vehicle, 5, 1, true)
							Citizen.Wait(500)
							SetVehicleDoorOpen(vehicle, 5, 1, true)
							
						end
						
					end
                    
                
                if IsControlJustReleased(0,23) then
                    DetachEntity(player)
		   			ClearPedTasks(player)  	  
		    		inside = false		
		   			ClearAllHelpMessages()
                end									
			elseif not DoesEntityExist(vehicle) and inside then		    			
			end  	
	  	end
	end)

function Streaming(animDict, cb)
	if not HasAnimDictLoaded(animDict) then
		RequestAnimDict(animDict)

		while not HasAnimDictLoaded(animDict) do
			Citizen.Wait(1)
		end
	end

	if cb ~= nil then
		cb()
	end
end	
function VehicleInFront()
    local pos = GetEntityCoords(player)
    local entityWorld = GetOffsetFromEntityInWorldCoords(player, 0.0, 6.0, 0.0)
    local rayHandle = CastRayPointToPoint(pos.x, pos.y, pos.z, entityWorld.x, entityWorld.y, entityWorld.z, 10, player, 0)
    local _, _, _, _, result = GetRaycastResult(rayHandle)
    return result
end