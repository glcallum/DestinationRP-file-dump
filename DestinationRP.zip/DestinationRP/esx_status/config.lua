Config = {}

Config.StatusMax      = 1000000
Config.TickTime       = 800
Config.UpdateInterval = 8000