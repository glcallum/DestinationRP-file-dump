Config                    = {}
Config.Locale             = 'en'
Config.EnableESXIdentity  = true
Config.MaxSalary          = 3500
