ESX                           = nil

Citizen.CreateThread(function()
    while ESX == nil do
      TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
      Citizen.Wait(0)
    end
end)

function VehicleInFront()
  local pos = GetEntityCoords(GetPlayerPed(-1))
  local entityWorld = GetOffsetFromEntityInWorldCoords(GetPlayerPed(-1), 0.0, 4.0, 0.0)
  local rayHandle = CastRayPointToPoint(pos.x, pos.y, pos.z, entityWorld.x, entityWorld.y, entityWorld.z, 10, GetPlayerPed(-1), 0)
  local a, b, c, d, result = GetRaycastResult(rayHandle)
  return result
end

RegisterNetEvent('esx_mecanojob:onFixkit') -- Repair Fully
AddEventHandler('esx_mecanojob:onFixkit', function()
  local playerPed = GetPlayerPed(-1)
  local coords    = GetEntityCoords(playerPed)

  if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 5.0) then

    local vehicle = nil

    if IsPedInAnyVehicle(playerPed, false) then
      vehicle = GetVehiclePedIsIn(playerPed, false)
    else
      vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 71)
    end

    if DoesEntityExist(vehicle) then
      local ad = "mini@repair"
      local vehFront = VehicleInFront()
      SetVehicleDoorOpen(vehFront, 4, false, false)
      ESX.Streaming.RequestAnimDict( ad )
      TaskPlayAnim(playerPed, ad, "fixing_a_player", 8.0, 1.0, -1, 49, 0, 0, 0, 0)
      exports["drp_taskbar"]:StartDelayedFunction('Repairing', 40000, function()
        Citizen.CreateThread(function()
          SetVehicleFixed(vehicle)
          SetVehicleDeformationFixed(vehicle)
          SetVehicleUndriveable(vehicle, false)
          ClearPedTasksImmediately(playerPed)
          exports['mythic_notify']:DoCustomHudText('success', 'Vehicle Repaired', 5000)
        end)
      end)
    end
  end
end)

RegisterNetEvent('esx_mecanojob:onFixkit2') -- Repair Half
AddEventHandler('esx_mecanojob:onFixkit2', function()
  local playerPed = GetPlayerPed(-1)
  local coords    = GetEntityCoords(playerPed)

  if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 5.0) then

    local vehicle = nil

    if IsPedInAnyVehicle(playerPed, false) then
      vehicle = GetVehiclePedIsIn(playerPed, false)
    else
      vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 71)
    end

    if DoesEntityExist(vehicle) then
      local ad = "mini@repair"
      local vehFront = VehicleInFront()
      SetVehicleDoorOpen(vehFront, 4, false, false)
      ESX.Streaming.RequestAnimDict( ad )
      TaskPlayAnim(playerPed, ad, "fixing_a_player", 8.0, 1.0, -1, 49, 0, 0, 0, 0)
      exports["drp_taskbar"]:StartDelayedFunction('Repairing', 15000, function()
        Citizen.CreateThread(function()
          SetVehicleBodyHealth(vehicle, 1000.0)
          SetVehicleUndriveable(vehicle, false)
          SetVehicleDeformationFixed(vehicle)
          ClearPedTasksImmediately(playerPed)
          exports['mythic_notify']:DoCustomHudText('success', 'Engine and Body Repaired', 5000)
        end)
      end)
    end
  end
end)

RegisterNetEvent('esx_mecanojob:onFixkit3') -- Repair only tires
AddEventHandler('esx_mecanojob:onFixkit3', function()
  local playerPed = GetPlayerPed(-1)
  local coords    = GetEntityCoords(playerPed)

  if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 5.0) then

    local vehicle = nil

    if IsPedInAnyVehicle(playerPed, false) then
      vehicle = GetVehiclePedIsIn(playerPed, false)
    else
      vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 71)
    end

    if DoesEntityExist(vehicle) then
      local ad = "mini@repair"
      local vehFront = VehicleInFront()
      SetVehicleDoorOpen(vehFront, 4, false, false)
      ESX.Streaming.RequestAnimDict( ad )
      TaskPlayAnim(playerPed, ad, "fixing_a_player", 8.0, 1.0, -1, 49, 0, 0, 0, 0)
      exports["drp_taskbar"]:StartDelayedFunction('Repairing', 5000, function()
        Citizen.CreateThread(function()
          SetVehicleTyreFixed(vehicle, 0)
          SetVehicleTyreFixed(vehicle, 1)
          SetVehicleTyreFixed(vehicle, 2)
          SetVehicleTyreFixed(vehicle, 3)
          SetVehicleTyreFixed(vehicle, 4)
          SetVehicleTyreFixed(vehicle, 5)
          ClearPedTasksImmediately(playerPed)
          exports['mythic_notify']:DoCustomHudText('success', 'Tires Repaired', 5000)
        end)
      end)
    end
  end
end)

RegisterNetEvent('esx_mecanojob:onFixkit4') -- Repair Engine ONLY
AddEventHandler('esx_mecanojob:onFixkit4', function()
  local playerPed = GetPlayerPed(-1)
  local coords    = GetEntityCoords(playerPed)

  if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 5.0) then

    local vehicle = nil

    if IsPedInAnyVehicle(playerPed, false) then
      vehicle = GetVehiclePedIsIn(playerPed, false)
    else
      vehicle = GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 71)
    end

    if DoesEntityExist(vehicle) then
      local ad = "mini@repair"
      local vehFront = VehicleInFront()
      SetVehicleDoorOpen(vehFront, 4, false, false)
      ESX.Streaming.RequestAnimDict( ad )
      TaskPlayAnim(playerPed, ad, "fixing_a_player", 8.0, 1.0, -1, 49, 0, 0, 0, 0)
      exports["drp_taskbar"]:StartDelayedFunction('Repairing', 35000, function()
        Citizen.CreateThread(function()
          SetVehicleEngineHealth(vehicle, 1000.0)
          SetVehicleUndriveable(vehicle, false)
          ClearPedTasksImmediately(playerPed)
          exports['mythic_notify']:DoCustomHudText('success', 'Engine Repaired', 5000)
        end)
      end)
    end
  end
end)