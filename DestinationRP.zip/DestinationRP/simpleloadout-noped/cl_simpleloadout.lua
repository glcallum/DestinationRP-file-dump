------
-- Simple Loadout Commands V1.0
-- By Julie Manlet
-- Do not remove credits !!
------

RegisterCommand("zleo", function(source, args, raw)
    TriggerEvent("leoloadout")
end, false)

RegisterNetEvent("leoloadout")
AddEventHandler("leoloadout", function()
    local ped = PlayerPedId()
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), 1000, false)
	GiveWeaponComponentToPed(GetPlayerPed(-1), GetHashKey("WEAPON_PISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
	--GiveWeaponToPed(ped, GetHashKey("WEAPON_COMBATPISTOL"), 1000, false)
	GiveWeaponComponentToPed(ped, GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("COMPONENT_AT_PI_FLSH"))
	--GiveWeaponToPed(ped, GetHashKey("WEAPON_CARBINERIFLE"), 1000, false)
	GiveWeaponComponentToPed(ped, GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_FLSH"))
	GiveWeaponComponentToPed(ped, GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("COMPONENT_AT_AR_AFGRIP"))
	GiveWeaponComponentToPed(ped, GetHashKey("WEAPON_CARBINERIFLE"), 0xA0D89C42)
	--GiveWeaponToPed(ped, GetHashKey("WEAPON_PUMPSHOTGUN"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_BZGAS"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_NIGHTSTICK"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_FLASHLIGHT"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_STUNGUN"), 1000, false)
end)

RegisterNetEvent("fdloadout")
AddEventHandler("fdloadout", function()
    local ped = PlayerPedId()
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_FLARE"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_FLASHLIGHT"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_STUNGUN"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_FLAREGUN"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_MOLOTOV"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_FIREEXTINGUISHER"), 1000, false)
    chatPrint("Your Fire Department loadout has been equipped!")	
end)

RegisterNetEvent("emsloadout")
AddEventHandler("emsloadout", function()
    local ped = PlayerPedId()
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_FLASHLIGHT"), 1000, false)
	--GiveWeaponToPed(GetPlayerPed(-1), GetHashKey("WEAPON_STUNGUN"), 1000, false)
    chatPrint("Your EMS loadout has been equipped!")	
end)

function chatPrint( msg )
	TriggerEvent( 'chatMessage', "^1Loadout System", { 0, 0, 0 }, msg )
end 

------
-- Do not remove credits !!
------