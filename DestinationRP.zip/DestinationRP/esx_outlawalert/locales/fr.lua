Locales['fr'] = {
  ['male'] = 'homme',
  ['female'] = 'femme',
  ['carjack'] = '~o~Vol de véhicule~s~: un(e) ~r~%s~s~ a été vu en ~o~%s~s~ a ~y~%s~s~',
  ['combat'] = '~o~Bagarre en cour~s~: un(e)  ~r~%s~s~ a déclenché une bagarre a ~y~%s~s~',
  ['gunshot'] = '~o~Coup de feu ~s~: un(e)  ~r~%s~s~ a tiré a ~y~%s~s~',
}