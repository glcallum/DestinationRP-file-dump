Locales['en'] = {
  ['male'] = 'male',
  ['female'] = 'female',
  ['carjack'] = '~o~Carjack in progress~s~: a ~r~%s~s~ was spotted jacking an ~o~%s~s~ at ~y~%s~s~',
  ['combat'] = '~o~Fight in progress~s~: a ~r~%s~s~ has been spotted fighting at ~y~%s~s~',
  ['gunshot'] = '~o~Shootout in progress~s~: a ~r~%s~s~ has been spotted firing a weapon at ~y~%s~s~',
}