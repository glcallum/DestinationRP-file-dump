Locales ['pl'] = {
	['unlocked'] = '~g~Otwarte~s~',
	['locked'] = '~r~Zamknięte~s~',
	['press_button'] = '[E] %s',
}
